=== 七牛镜像存储 WordPress 插件 ===
Contributors: denishua
Donate link: https://me.alipay.com/denishua
Tags: CDN
Requires at least: 3.0
Tested up to: 3.6
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

七牛镜像存储 WordPress 插件：一键实现 WordPress 博客静态文件 CDN 加速。

== Description ==

七牛支持传统 CDN 的镜像存储，对于很多 WordPress 站点来说，有了这个功能，就无需将原来的图片上传到七牛的服务器上，只需在 WordPress 站点做些简单的修改，就可以使用七牛的 CDN 服务了。

详细介绍： http://blog.wpjam.com/project/wpjam-qiniutek/


== Installation ==

1. 上传 `wpjam-qiniutek`目录 到 `/wp-content/plugins/` 目录
2. 在后台插件菜单激活该插件
3. 在后台设置你在七牛绑定的域名即可

== Screenshots ==

1. 七牛镜像存储设置
2. 更新文件

== Changelog ==

= 0.3 =
* 支持在 WordPress 后台更新文件。

= 0.2 =
* 支持所有静态文件镜像到七牛

= 0.1 =
* 初始版本