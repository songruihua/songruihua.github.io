<?php
/*
Plugin Name: WPJAM 七牛镜像存储
Description: 使用七牛云存储实现 WordPress 博客静态文件 CDN 加速！
Plugin URI: http://blog.wpjam.com/m/qiniutek/
Author: Denis
Author URI: http://blog.wpjam.com/
Version: 0.3
*/

$wpjam_qiniutek = (array) get_option( 'wpjam-qiniutek' );

if(isset($wpjam_qiniutek ['host'])){
	//定义在七牛绑定的域名。
	define('CDN_HOST',$wpjam_qiniutek ['host']);
}

if(!is_admin()){
	
	if(isset($wpjam_qiniutek ['host'])){

		add_action("wp_loaded", 'wpjam_qiniutek_start_ob_cache' ,9999);
		function wpjam_qiniutek_start_ob_cache(){
			ob_start();
		}

		add_action("wp_footer", 'wpjam_qiniutek_stop_ob_cache' ,9999);
		function wpjam_qiniutek_stop_ob_cache(){
			$html = ob_get_contents();
			ob_end_clean();
			$regex = '/'.str_replace('/','\/',home_url()).'\/((wp-content|wp-includes)\/[^\s]{1,}.(js|css|png|jpg|jpeg|gif|ico)[^\"\'\s]{0,})/';
			echo preg_replace($regex, CDN_HOST.'/$1', $html);
		}
	}
}

add_action( 'admin_menu', 'wpjam_qiniutek_admin_menu' );
function wpjam_qiniutek_admin_menu() {
	add_menu_page(						'七牛镜像存储',			'七牛镜像存储',	'manage_options',	'wpjam-qiniutek',		'wpjam_qiniutek_setting_page',	WP_CONTENT_URL.'/plugins/wpjam-qiniu/qiniutek-ico.png'	);
	add_submenu_page( 'wpjam-qiniutek',	'七牛镜像存储设置',		'基本设置',		'manage_options',	'wpjam-qiniutek',		'wpjam_qiniutek_setting_page'	);
	add_submenu_page( 'wpjam-qiniutek',	'七牛镜像存储文件更新',	'文件更新',		'manage_options',	'wpjam-qiniutek-update','wpjam_qiniutek_update_page'	);
}

add_action('admin_head','wpjam_qiniutek_admin_head');
function wpjam_qiniutek_admin_head(){
?>
	<style>
	#icon-qiniutek{background-image: url("<?php echo WP_CONTENT_URL?>/plugins/wpjam-qiniu/qiniutek.png");background-repeat: no-repeat;}
	</style>
<?php
}

function wpjam_qiniutek_update_file($file){
	global $qiniutek_client, $qiniutek_bucket;

	if(!$qiniutek_client){
		$wpjam_qiniutek = get_option( 'wpjam-qiniutek' );
		require_once(WP_CONTENT_DIR."/plugins/wpjam-qiniu/sdk/rs.php");
		
		Qiniu_SetKeys($wpjam_qiniutek['access'], $wpjam_qiniutek['secret']);
		$qiniutek_client = new Qiniu_MacHttpClient(null);
		$qiniutek_bucket = $wpjam_qiniutek['bucket'];
	}

	$file_array = parse_url($file);
	$key = str_replace('http://'.$file_array['host'].'/', '', $file);
	$err = Qiniu_RS_Delete($qiniutek_client, $qiniutek_bucket, $key);
	if ($err !== null) {
		$msg = ' 发生错误：<span style="color:red">'.$err->Err.'</span><br />';
	} else {
		$msg = ' 清理成功<br />';
	}
	return $msg;
}

function wpjam_qiniutek_update_page(){

	if( $_SERVER['REQUEST_METHOD'] == 'POST' ){

		if ( !wp_verify_nonce($_POST['wpjam_qiniutek_update'],'wpjam_qiniutek') ){
			ob_clean();
			wp_die('非法操作');
		}
		
		$updates = ($_POST['updates']);

		$updates_array = explode("\n", $updates);

		$msg = '';
		foreach ($updates_array as $update) {
			if(trim($update)){
				$msg = $msg.$update.wpjam_qiniutek_update_file($update);
			}
		}
	}

	?>
	<div class="wrap">
		<div id="icon-qiniutek" class="icon32"><br></div>
		<h2>更新文件</h2>

		<?php if(!empty($msg)){?>
		<div class="updated">
			<p><?php echo $msg;?></p>
		</div>
		<?php }?>

		<?php 
		$wpjam_qiniutek = get_option( 'wpjam-qiniutek' ); 
		if(empty($wpjam_qiniutek['bucket']) || empty($wpjam_qiniutek['access']) || empty($wpjam_qiniutek['secret']) ){
			echo '<p>你还没有设置七牛的空间名或 ACCESS，SECRET KEY，请到<a href="'.admin_url('admin.php?page=wpjam-qiniutek').'">这里</a>设置</p>';
		}else{

		?>

		<form method="post" action="<?php echo admin_url('admin.php?page=wpjam-qiniutek-update'); ?>" enctype="multipart/form-data" id="form">
		<table class="form-table" cellspacing="0">
			<tbody>
				<tr valign="top">
					<td>
						<p>请输入需要更新的文件，每行一个：</p>
						<textarea name="updates" rows="10" cols="50" id="updates" class="large-text code"><?php echo $updates; ?></textarea>
					</td>
			</tbody>
		
		</table>
		<?php wp_nonce_field('wpjam_qiniutek','wpjam_qiniutek_update'); ?>
		<input type="hidden" name="action" value="edit" />
		<p class="submit"><input class="button-primary" type="submit" value="更新文件" /></p>
		</form>
		<ol>
			<li>点击“更新文件”按钮之后，只要文件后面显示更新成功，即代表更新成功。</li>
			<li>如果实时查看还是旧的文件，可能是你浏览器的缓存，你需要清理下缓存，或者等待自己更新。</li>
			<li>图片缩略图更新七牛是按照按照队列顺序进行的，需要等待一定的时间，只要看到原图更新即可。</li>
		</ol>
		<?php } ?>
	</div>
<?php
}

function wpjam_qiniutek_setting_page() {
	?>
	<div class="wrap">
		<div id="icon-qiniutek" class="icon32"><br></div>
		<h2>七牛镜像存储设置</h2>
		<form action="options.php" method="POST">
			<?php settings_fields('wpjam-qiniutek-group'); ?>
			<?php do_settings_sections('wpjam-qiniutek'); ?>
			<?php submit_button(); ?>
		</form>

		<ol>
			<li>该插件只需要输入你在七牛绑定的域名（第一个选项）就可以工作，<strong>注意要域名前面要加上 http://，结尾无需 / </strong>。</li>
			<li>后三个选项是为文件更新服务的，如果你只需要使用 CDN 功能，不需要在 WP 后台更新文件，可不填。</li>
			<li>ACCESS KEY 和 SECRET KEY 请到 <a href="https://portal.qiniu.com/setting/key" target="_blank">https://portal.qiniu.com/setting/key</a> 获取。</li>
			<li>更详细图文使用说明请点击：<strong><a href="http://blog.wpjam.com/project/wpjam-qiniutek/" target="_blank">七牛镜像存储 WordPress 插件：一键实现 WordPress 博客静态文件 CDN 加速</a></strong>。</li>
		</ol>
	</div>
	<?php
}

add_action( 'admin_init', 'wpjam_qiniutek_admin_init' );
function wpjam_qiniutek_admin_init() {
	
	register_setting( 'wpjam-qiniutek-group', 'wpjam-qiniutek', '' );
	add_settings_section( 'wpjam-qiniutek-section', '', '', 'wpjam-qiniutek' );

	$wpjam_qiniutek_settings_fields = array(
		array('name'=>'host',	'title'=>'七牛绑定的域名',	'type'=>'text',	'default'=>'http://xxxx.qiniudn.com',	'description'=>'设置为你在七牛绑定的域名即可。<strong>注意要域名前面要加上 http://，结尾无需 / </strong>。'),
		array('name'=>'bucket',	'title'=>'空间名',			'type'=>'text',	'default'=>'',						 	'description'=>'设置为你在七牛绑定的空间名即可。'),
		array('name'=>'access',	'title'=>'ACCESS KEY',		'type'=>'text',	'default'=>'',							),
		array('name'=>'secret',	'title'=>'SECRET KEY',		'type'=>'text',	'default'=>'',							),
	);

	foreach ($wpjam_qiniutek_settings_fields as $field) {
		add_settings_field( 
			$field['name'],
			$field['title'],		
			'wpjam_qiniutek_settings_field_callback',	
			'wpjam-qiniutek', 
			'wpjam-qiniutek-section',	
			$field
		);
	}
}

function wpjam_qiniutek_settings_field_callback($args) {
	$wpjam_qiniutek = (array) get_option( 'wpjam-qiniutek' );
	
	if($args['type'] == 'text'){
		if(isset($wpjam_qiniutek[$args['name']])){
			$value = $wpjam_qiniutek[$args['name']];
		}
		if($value == '') $value = $args['default'];
		echo '<input type="text" name="wpjam-qiniutek['.$args['name'].']" value="'.$value.'" class="regular-text" />';
	}elseif($args['type'] == 'checkbox'){
		$checked = '';
		if(isset($wpjam_qiniutek[$args['name']])){
			$value = $wpjam_qiniutek[$args['name']];
			if($value){
				$checked = 'checked';
			}
		}
		echo '<label for="wpjam-qiniutek['.$args['name'].']"><input name="wpjam-qiniutek['.$args['name'].']" type="checkbox" id="wpjam-qiniutek['.$args['name'].']" ' . $checked . ' value="1">'.$args['label'].'</label>';
	}
	if(isset($args['description'])) echo '<p class="description">'.$args['description'].'</p>';
}